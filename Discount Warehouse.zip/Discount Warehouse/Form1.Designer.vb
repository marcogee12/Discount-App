﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtOrgPrice = New System.Windows.Forms.TextBox()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.txtDiscPrice = New System.Windows.Forms.TextBox()
        Me.lstDiscounts = New System.Windows.Forms.ListBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label1.Location = New System.Drawing.Point(99, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Original Price:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label2.Location = New System.Drawing.Point(525, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(186, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Discount Rates (%):"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label3.Location = New System.Drawing.Point(125, 219)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(94, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Discount:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label4.Location = New System.Drawing.Point(525, 219)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(165, 25)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Discounted Price:"
        '
        'txtOrgPrice
        '
        Me.txtOrgPrice.Location = New System.Drawing.Point(119, 78)
        Me.txtOrgPrice.Name = "txtOrgPrice"
        Me.txtOrgPrice.Size = New System.Drawing.Size(100, 26)
        Me.txtOrgPrice.TabIndex = 4
        '
        'txtDiscount
        '
        Me.txtDiscount.Location = New System.Drawing.Point(119, 247)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(100, 26)
        Me.txtDiscount.TabIndex = 5
        '
        'txtDiscPrice
        '
        Me.txtDiscPrice.Location = New System.Drawing.Point(554, 247)
        Me.txtDiscPrice.Name = "txtDiscPrice"
        Me.txtDiscPrice.Size = New System.Drawing.Size(100, 26)
        Me.txtDiscPrice.TabIndex = 6
        '
        'lstDiscounts
        '
        Me.lstDiscounts.FormattingEnabled = True
        Me.lstDiscounts.ItemHeight = 20
        Me.lstDiscounts.Items.AddRange(New Object() {"10", "15", "20", "25", "30", "35", "45"})
        Me.lstDiscounts.Location = New System.Drawing.Point(554, 78)
        Me.lstDiscounts.Name = "lstDiscounts"
        Me.lstDiscounts.Size = New System.Drawing.Size(120, 84)
        Me.lstDiscounts.TabIndex = 7
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btnCalc.Location = New System.Drawing.Point(250, 364)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(121, 42)
        Me.btnCalc.TabIndex = 8
        Me.btnCalc.Text = "Caclulate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btnExit.Location = New System.Drawing.Point(427, 364)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(101, 42)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(822, 466)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lstDiscounts)
        Me.Controls.Add(Me.txtDiscPrice)
        Me.Controls.Add(Me.txtDiscount)
        Me.Controls.Add(Me.txtOrgPrice)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Discount Warehouse"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtOrgPrice As TextBox
    Friend WithEvents txtDiscount As TextBox
    Friend WithEvents txtDiscPrice As TextBox
    Friend WithEvents lstDiscounts As ListBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
End Class
