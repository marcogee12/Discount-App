﻿' Name:         Discount Warehouse'
' Purpose:      Calculate an arbitrary price discounted at price.'
'               Display discount and discounted price.'
' Programmer:   Marco Gomez on 6/20/2019
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs)

    End Sub

    'Sets the Calculate button as the default button'
    Private Sub Form1_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load
        AcceptButton = btnCalc
    End Sub

    'Calculates the discount and discounted price'
    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'Scope of variabled used to calculate discount and discount price.'
        'Stores original price for discount and discounted price calculations.'
        Dim orgPrice As Double = txtOrgPrice.Text
        Dim discPercent As Double = (lstDiscounts.SelectedItem)

        'Evaluates if there is a discount selection and if there isnt a selected index discPercent will be 0.'
        If lstDiscounts.SelectedIndex = -1 Then
            discPercent = 0
        End If

        'Caculation for discount'
        Dim discount As Double = orgPrice / 100 * discPercent

        'Calculation for discounted price'
        Dim discPrice As Double = orgPrice - discount

        'Displays discount and discounted price as currency'
        txtDiscount.Text = FormatCurrency(discount)
        txtDiscPrice.Text = FormatCurrency(discPrice)
    End Sub

    'Send close app event to the exit button'
    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
